﻿import os #导入磁盘文件的模块
filename='Student information.txt'
#   主函数
def main():

    while True:
        menm()
        choice=int(input('请选择执行功能：'))
        if choice in [0,1,2,3,4,5,6,7]:

            if choice==0:
                answer=input('您确定要退出系统吗？y/n：')
                if answer=='y' or answer=='Y':
                    print('答辩演示结束，谢谢大家收看!')
                    break   #退出系统
                else:
                    continue
            # 录入学生信息
            elif choice == 1:
                insert()

            # 查找学生信息
            elif choice == 2:
                search()

            # 删除学生信息
            elif choice == 3:
                delete()

            # 修改学生信息
            elif choice == 4:
                modify()

            # 显示学生信息
            elif choice == 5:
                show()

            # 学生信息排序
            elif choice == 6:
                sort()

            # 统计学生信息
            elif choice == 7:
               total()

        # 异常处理
        else:
            print('操作异常，请重新输入正确选择！')

def menm():
    print('=========================201906160077======================================')
    print('========================== 冯 宇 宏 ========================================')
    print('=========================学生信息管理系统=====================================')
    print('----------------------------功能目录----------------------------------------')
    num = 6
    list77 = ['1.注册学生信息','2.查找学生信息','3.删除学生信息','4.修改学生信息','5.显示学生信息','6.学生信息排序','7.学生信息统计','0.退出']
    for i in range(len(list77)):
        print('\t'*num + list77[i])
    print('---------------------------------------------------------------------------')

#函数定义要实现功能的函数
#注册学生信息功能，save（student）函数，用于将学生信息保存到文件，insert（）函数，用于注册录入学生信息

#注册 学生信息
def insert():
    student_list=[] #存储学生
    while True:
        print("开始注册，请按步骤输入注册信息")
        id=input('请输入学号ID (例2019061600XX）:')
        if not id:
            break
        name=input('请输入学生姓名:')
        if not name:
            break

#异常捕获抛出
        try:
            Age=int(input('请输入 年龄：'))
            Python=int(input('请输入 Python 成绩：'))
            Java=int(input('请输入 Java 成绩：'))
        except:
            print('输入无效，输入非整数类型，请重新输入')
            continue

        #将录入的学生信息保存到字典中
        student={'id':id,'name':name,'Age':Age,'Python':Python,'Java':Java}
        #将学生信息添加到列表中
        student_list.append(student)
        answer=input('是否继续添加？y/n\n')
        if answer=='y' or answer == 'Y':
            continue
        else:
            break
    #调用save（）函数
    save(student_list)
    print('学生信息注册完成!')

#文件操作
def save(list):
    try:
        stu_txt=open(filename,'a',encoding='utf-8')  #a是有的时候追加，没有就创建
    except:
        stu_txt=open(filename,'w',encoding='utf-8')  #w是以写入的方式打开
    for item in list:
        stu_txt.write(str(item)+'\n') #\n换行
    stu_txt.close()

#查找 学生信息
def search():#是一个查询过程
    student_query=[]   #定义一个列表，防止同名
    while True:
        id=''
        name=''
        if os.path.exists(filename):
            mode=input('按ID查找请按0，按姓名查找请按1：')
            if mode=='0':
                id=input('请输入学生学号ID：')
            elif mode=='1':
                name=input('请输入学生姓名：')
            else:
                print('您的输入有误，请重新尝试')
                search()
            with open(filename,'r',encoding='utf-8') as rfile:
                student=rfile.readlines()
                for item in student:
                    d=dict(eval(item))
                    if id!='':
                        if d['id']==id:
                            student_query.append(d)
                    elif name!='':
                        if d['name']==name:
                            student_query.append(d)
            #显示查询结果
            show_student(student_query)
            #情况列表
            student_query.clear()
            answer=input('是否要继续查询？y/n\n')
            if answer=='y' or answer == 'Y':
                continue
            else:
                break

        else:
            print('暂未保存学生信息')
            return
    pass

#显示查询结果
def show_student(lst):
    if len(lst)==0:
        print('未能查询相关学生信息')
        return
    #定义标题显示格式
    format_title='{:^6}\t\t\t{:^12}\t{:^8}\t\t{:^10}\t\t{:^10}\t\t{:^8}'#字符串
    print(format_title.format('ID','姓名','年龄','Python成绩','Java成绩','总成绩'))#占了id，姓名等的位置
    #定义内容显示格式
    format_data='{:^6}\t{:^12}\t{:^8}\t\t{:^10}\t\t{:^10}\t\t{:^8}'
    for item in lst:
        print(format_data.format(item.get('id'),
                                 item.get('name'),
                                 item.get('Age'),
                                 item.get('Python'),
                                 item.get('Java'),
                                 int(item.get('Python'))+int(item.get('Java'))
                                 ))

#删除 学生信息
def delete():
    while True:#循环变量
        student_id=input('请输入要删除的学生的学号ID：')
        if student_id!='':
            if os.path.exists(filename): #判断磁盘上的文件是否存在
                with open(filename,'r',encoding='utf-8') as file:#模式是r，编码格式是utf-8
                    student_old=file.readlines()#读取文件
            else:  #学生信息不存在
                student_old=[]  #定义一个列表为空
            flag=False   #标记是否删除（默认没有删除）
            if student_old:  #判断列表（删除完的将原有的进行覆盖）空列表布尔值为False
                with open(filename,'w',encoding='utf-8') as wfile: #w:以只写模式打开文件,如果文件存在，则覆盖原有内容
                    d={}  #定义空字典
                    for item in student_old:#遍历一遍
                        d=dict(eval(item))#eval（）函数将字符串转成字典
                        if d['id']!=student_id:  #判断删除的学生在字典中存不存在
                            wfile.write(str(d)+'\n')  #如果不存在，将学生信息先写入文件（这里写入的是原有的信息）
                        else:#ID相等的情况下
                            flag=True #标记已删除
                    if flag:  #判断flag的值
                        print(f'ID为{student_id}的学生信息已被删除') #格式化字符串f
                    else:
                        print(f'未找到ID为{student_id}同学的相关信息')
            else: #不存在学习信息
                print('学生信息不存在')
                break
            show()#删除之后要重新显示所有学生信息
            answer=input('是否继续删除？y/n\n')
            if answer=='y':
                continue
            else:
                break

#修改 学生信息
def modify():
    show()#调用show函数，显示所有学生信息
    if os.path.exists(filename):
        with open(filename,'r',encoding='utf-8') as rfile:
            student_old=rfile.readlines()
    else:
        return
    student_id=input('请输入要修改的学生的ID：')
    with open(filename,'w',encoding='utf-8') as wfile:   #只写模式
        for item in student_old:
            d=dict(eval(item))
            if d['id']==student_id:
                print('找到学生信息，可以进行修改')
                while True:
                    try:
                        d['name']=input('请输入姓名:')
                        d['Age']=input('请输入年龄：')
                        d['Python']=input('请输入Python成绩：')
                        d['Java']=input('请输入Java成绩：')
                    except:
                        print('您的输入有误，请重新尝试')
                    else:
                        break#正常情况下，则退出循环
                wfile.write(str(d)+'\n') #将字典转成字符串类型
                print('修改成功！')
            else:
                wfile.write(str(d)+'\n')
            answer=input('是否继续修改其他学生信息呢？y/n\n')
            if answer=='y':
                modify()#调用modify（）函数，是一种重复的过程
            else:
                break

#排序 学生信息
def sort():
    show()
    if os.path.exists(filename):
        with open(filename,'r',encoding='utf-8') as rfile:
            student_list=rfile.readlines() #读取全部信息到列表
        student_new=[]
        for item in student_list:
            d=dict(eval(item))#将学生信息转换为字典并添加到列表当中
            student_new.append(d)
    else:
        return
    #选择排序方式
    asc_or_desc=input('请选择(0.升序 1.降序):')
    if asc_or_desc=='0':
        asc_or_desc_bool=False
    elif asc_or_desc=='1':
        asc_or_desc_bool=True
    else:
        print('您的输入有误，请重新尝试')
        sort()
    mode=input('请选择排序方式(0.按年龄排序 1.按Python成绩排序 2.按Java成绩排序 3.按总成绩排序):')
    if mode=='0':
        student_new.sort(key=lambda x:int(x['Age']),reverse=asc_or_desc_bool)#x是一个参数，是一个字典  在字典中根据键去获取值然后进行int类型的转换，最后将结果赋给key
    elif mode=='1':
        student_new.sort(key=lambda x:int(x['Python']),reverse=asc_or_desc_bool)
    elif mode=='2':
        student_new.sort(key=lambda x:int(x['Java']),reverse=asc_or_desc_bool)
    elif mode=='3':
        student_new.sort(key=lambda x:int(x['Python'])+int(x['Java']),reverse=asc_or_desc_bool)
    else:
        print('您的输入有误，请重新尝试!')
        sort()
    show_student(student_new)

    pass

#统计 学生信息
def total():
    if os.path.exists(filename):
        with open(filename,'r',encoding='utf-8') as rfile:
            students=rfile.readlines()
            if students:  #判断学生列表是否为空列表
                print(f'系统当前共有{len(students)}名学生数据.\n')  #列表中元素的个数
            else:
                print('还未录入学生信息')
    else:
        print('数据无保存。。。。')
    pass

#显示 学生信息
def show():
    student_lst=[]   #存储学员信息的
    if os.path.exists(filename):
        with open(filename,'r',encoding='utf-8') as rfile: #只读文件
            students=rfile.readlines()
            for item in students:
                student_lst.append(eval(item))
            if student_lst:   #如果列表不为空的话
                show_student(student_lst)  #show_student()函数是之前查询信息显示结果的那个函数

    pass


#以主程序的方式去调用运行
if __name__ == '__main__':
    main()
'''补充：在key=lambda x:int(x[' '])中，lambda函数是按照元素（键）进行排序,比如之前输入0为升序，则asc_or_desc_bool为False即reverse=False,为正序排序。 '''

